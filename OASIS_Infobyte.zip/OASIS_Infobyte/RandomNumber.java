import java.util.Random;
import java.util.Scanner;

public class RandomNumber {
    public static void main(String[] args) {
        int ans, guess;
        final int MAX = 100;

        Scanner keyboard = new Scanner(System.in);
        Random rand = new Random();

        ans = rand.nextInt(MAX) + 1;
        System.out.print("Guess a number between 1 and 100:");
        guess = keyboard.nextInt();

        if (guess == ans) {
            System.out.println("Good job,The number was " + ans);
        } else {
            System.out.println("Sorry,But the number was " + ans);
        }
    }
}